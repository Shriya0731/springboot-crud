insert into Friend values('C22020881907','Tanvi Bhosale','tanvi.bhosale@gmail.com','Computer');
insert into Friend values('C2202881910','Sayali Deshmukh','sayali.deshmukh@gmail.com','Computer');
insert into Friend values('C22020881912','Shriya Deshpande','shriya.deshpande@gmail.com','Computer');
